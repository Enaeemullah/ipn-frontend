## 0.8.0 (2021/04/18)

- Remove the `input[value]` hack (#9)
- Fix Bootstrap peer dependency
- Fix label color for disabled/readonly input & disabled select
- Refactor example: make things more clear
- Update npm packages

## 0.7.0 (2020/05/14)

- Support for IE >= 10 :-ms-input-placeholder
- Breaking change: rename bootstrap4-floating-label.scss to bootstrap-floating-label.scss
  - I won't have the man power to maintain Bootstrap 4 & 5

## 0.6.1 (2020/05/13)

- Update demo.gif, make it retina
- Datalist example
- Bootstrap 4.5.0
- TypeScript 3.9.2

## 0.6.0 (2020/05/12)

- Placeholder should be grey (\$input-placeholder-color) instead of black
- Update npm packages

## 0.5.1 (2020/03/17)

- Improve documentation and example
- CI/CD with GitHub Actions
- Update npm packages

## 0.5.0 (2020/01/05)

- RTL support
- Update npm packages

## 0.4.0 (2019/10/10)

- Add .label-md and .label-lg

## 0.3.1 (2019/09/23)

- v0.3.0: wrong branch published :-/

## 0.3.0 (2019/09/21)

- Fix top position calculation
- Supports form-control-sm and form-control-lg
- More examples
- Improve z-index usage: better with addon button under IE with slow animation
- Upgrade npm packages

## 0.2.0 (2019/09/06)

- Support select
- Fix z-index when using addons

## 0.1.0 (2019/06/19)

- Document the "space placeholder"

## 0.0.4 (2019/06/09)

- Upgrade npm packages

## 0.0.3 (2019/03/25)

- Improve documentation

## 0.0.2 (2019/03/18)

- Fix npmjs.com demo.gif by setting a repository URL

## 0.0.1 (2019/03/18)

First release
